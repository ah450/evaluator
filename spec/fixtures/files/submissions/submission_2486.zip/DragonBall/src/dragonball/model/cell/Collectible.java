package dragonball.model.cell;

public enum Collectible 
{
	SENZU_BEANS, DRAGON_BALL;
}
