package dragonball.model.cell;
/*import java.util.ArrayList;

import dragonball.model.character.fighter.*;
import dragonball.model.game.*;
import dragonball.model.world.*;*/

//Question: which cell is going to be checked? to be able to access it 

abstract public class Cell 
{

	abstract public String toString();

	

}
