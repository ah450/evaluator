package dragonball.model.attack;

public class SuperAttack extends Attack {

	public SuperAttack(String name, int damage) /*check if we can keep it like that or not to avoid 
												  the user being able to write by himself the damage etc*/
	{
		super(name, damage);
	}
	
	
	

}
