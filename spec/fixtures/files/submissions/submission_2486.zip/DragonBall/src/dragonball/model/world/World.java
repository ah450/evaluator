package dragonball.model.world;
import java.util.ArrayList;
import java.util.Random;

import dragonball.model.cell.*;
import dragonball.model.character.fighter.*;



public class World {
	private Cell[][] map;
	private int playerColumn;
	private int playerRow;
	

	public World() {
		map = new Cell[10][10];
	   
	}
	
	public void generateMap(ArrayList<NonPlayableFighter> weakFoes, ArrayList<NonPlayableFighter> strongFoes)
	{
		
		Random randomGenerator = new Random();
		
		//random boss
		// to check (use the getter or not etc)
		int index = randomGenerator.nextInt(strongFoes.size());
		
		map[0][0] =  (FoeCell) (Object) strongFoes.get(index);
		
		//random weak foes
		int x= 0;
		int y = 0;
		
		for (int i = 0; i<15 ;i++)
		{
			index = randomGenerator.nextInt(weakFoes.size());
	
			do
			{
				x = (int) Math.floor(Math.random() * 9);
				y = (int) Math.floor(Math.random() * 9);
			}
			while (map[x][y] == (Cell) (Object) weakFoes || (x == 0 && y == 0) );
		
			map[x][y] = (FoeCell) (Object) weakFoes.get(index);	
			
		}
		
		//random senzu beans
		int j =  3 + (int)(Math.random() * ((5 - 2) + 1));
		
		for ( int i = 0; i<j ;i++)
		{
		do
		{
			x = (int) Math.floor(Math.random() * 9);
			y = (int) Math.floor(Math.random() * 9);
		}
		while (map[x][y] == (FoeCell) (Object) weakFoes || (x == 0 && y == 0) || map[x][y] == (CollectibleCell) (Object) Collectible.SENZU_BEANS);
		
		
		map[x][y] = (CollectibleCell) (Object) Collectible.SENZU_BEANS;
		
		}
		
		//1dragon ball
		
		do
		{
			x = (int) Math.floor(Math.random() * 9);
			y = (int) Math.floor(Math.random() * 9);
		}
		
		while (map[x][y] == (FoeCell) (Object) weakFoes || (x == 0 && y == 0) || map[x][y] == (CollectibleCell) (Object) Collectible.SENZU_BEANS);
		
		map[x][y] = (CollectibleCell) (Object) Collectible.DRAGON_BALL;
		
		
		
		
	}

	public Cell[][] getMap() {
		return map;
	}


	public int getPlayerColumn() {
		return playerColumn;
	}


	public int getPlayerRow() {
		return playerRow;
	}

	
}
