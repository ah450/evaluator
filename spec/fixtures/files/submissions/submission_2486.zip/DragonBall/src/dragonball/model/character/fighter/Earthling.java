package dragonball.model.character.fighter;
import java.util.ArrayList;

import dragonball.model.attack.*;




public class Earthling extends PlayableFighter {
	
	/*
	public Earthling(String name, int level, int xp, int targetXp,
			int maxHealthPoints, int blastDamage, int physicalDamage,
			int abilityPoints, int maxKi, int maxStamina,
			ArrayList<SuperAttack> superAttacks,
			ArrayList<UltimateAttack> ultimateAttacks, boolean transformed) {
		
		super(name, level, xp, targetXp, 1250, 50,
				50, abilityPoints, 4, 4, superAttacks,
				ultimateAttacks);
				*/
	
	public Earthling(String name, int xp, int targetXp,
			int abilityPoints, 
			ArrayList<SuperAttack> superAttacks,
			ArrayList<UltimateAttack> ultimateAttacks, boolean transformed) {
		
		super(name, level, xp, targetXp, 1250, 50,
				50, abilityPoints, 4, 4, superAttacks,
				ultimateAttacks);
	}

}
