apackage dragonball.model.game;
import java.util.ArrayList;
import java.util.Arrays;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

import dragonball.model.attack.*;
import dragonball.model.character.fighter.*;
import dragonball.model.dragon.*;
import dragonball.model.player.*;
import dragonball.model.world.*;

public class Game {
	private Player player;
	private World world;
	private ArrayList<NonPlayableFighter> weakFoes;
	private ArrayList<NonPlayableFighter> strongFoes;
	private ArrayList<Attack> attacks;
	private ArrayList<Dragon> dragons;
	
	public Game()
	{
		
	}
	
	public ArrayList<String> loadCSV(String filePath) throws IOException
	{
		
		//Question: how are we supposed to store in the array list: each dragon 
		
		String currentLine = "";
		FileReader fileReader= new FileReader(filePath);
		BufferedReader br = new BufferedReader(fileReader);
		String[] dataArray = new String[weakFoes.size() + strongFoes.size()];
		ArrayList<String> dataList= new ArrayList<String>();
		int i=0;
		                                
		
		while ((currentLine = br.readLine()) != null) 
			{
				dataArray =  currentLine.split(",");
				
				while (dataArray[i] != null)
				{
				dataList.add(dataArray[i]);
				}
				
				/*for (String item:dataArray)
				{
					System.out.print(item + "\t");
				}
			
				System.out.println();*/
				
				currentLine = br.readLine();
				
			}
		
		br.close();
		return dataList;
		
		//System.out.println();
	}
	
	
	
	/*public static void main(String[] args) throws IOException
	{
		loadCSV(".csv");
	}*/
	

	
	
	
	private void loadAttacks(String filePath)throws IOException
	{
		attacks =  loadCSV("Attacks_Database.csv");
	}
	
	private void loadFoes(String filePath)throws IOException
	{
		loadCSV("Foes_Database.csv");
	}
	
	private void loadDragons(String filePath)throws IOException
	{
		dragons =  (Dragon) Arrays.asList(loadCSV("Dragons_Database.csv"));
	}
	
	
	
	
	public Player getPlayer() {
		return player;
	}

	public World getWorld() {
		return world;
	}
	
	public ArrayList<NonPlayableFighter> getWeakFoes() {
		return weakFoes;
	}
	
	public ArrayList<NonPlayableFighter> getStrongFoes() {
		return strongFoes;
	}
	
	public ArrayList<Attack> getAttacks() {
		return attacks;
	}
	
	public ArrayList<Dragon> getDragons() {
		return dragons;
	}
	

	
	
}
