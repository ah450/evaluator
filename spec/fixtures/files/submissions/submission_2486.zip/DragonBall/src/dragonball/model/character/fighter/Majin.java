package dragonball.model.character.fighter;
import java.util.ArrayList;

import dragonball.model.attack.*;

public class Majin extends PlayableFighter{
	
	public Majin(String name, int level, int xp, int targetXp,
			int maxHealthPoints, int blastDamage, int physicalDamage,
			int abilityPoints, int maxKi, int maxStamina,
			ArrayList<SuperAttack> superAttacks,
			ArrayList<UltimateAttack> ultimateAttacks, boolean transformed) {
		
		super(name, level, xp, targetXp, 1500, 50,
				50, abilityPoints, 3, 6, superAttacks,
				ultimateAttacks);
	}

}
