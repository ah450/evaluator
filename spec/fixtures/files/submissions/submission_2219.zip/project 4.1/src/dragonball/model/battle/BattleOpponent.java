package dragonball.model.battle;

public interface BattleOpponent {
	
	public void setHealthPoints(int healthPoints);
	public int getMaxHealthPoints();
	public void setKi(int ki);
	public void setStamina(int stamina);
	public int getMaxStamina() ;
}
