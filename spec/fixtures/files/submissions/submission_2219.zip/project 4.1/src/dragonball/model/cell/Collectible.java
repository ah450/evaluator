package dragonball.model.cell;

public enum Collectible {
       SENZU_BEAN,DRAGON_BALL;
}
