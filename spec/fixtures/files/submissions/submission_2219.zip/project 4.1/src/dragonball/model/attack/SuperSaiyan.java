package dragonball.model.attack;

public class SuperSaiyan extends UltimateAttack{
	   public SuperSaiyan(){
		   super( "Super Saiyan" ,0);
	   }

}
