package dragonball.model.cell;

abstract public class Cell {

	abstract public String toString();


}
