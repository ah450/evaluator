package dragonball.model.game;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

import dragonball.model.attack.Attack;
import dragonball.model.attack.MaximumCharge;
import dragonball.model.attack.SuperAttack;
import dragonball.model.attack.SuperSaiyan;
import dragonball.model.attack.UltimateAttack;
import dragonball.model.character.fighter.NonPlayableFighter;
import dragonball.model.dragon.Dragon;
import dragonball.model.player.Player;
import dragonball.model.world.World;

public class Game {
	private Player player;
	private World world;
	private ArrayList<NonPlayableFighter> strongFoes;
	private ArrayList<NonPlayableFighter> weakFoes;
	private ArrayList<Attack> attacks;
	private ArrayList<Dragon> dragons;

	public Game() throws IOException {
		loadAttacks("Database-Attacks.csv");
		loadFoes("Database-Foes.csv");
		loadDragons("Database-Dragons.csv");
		world = new World();
		world.generateMap(weakFoes, strongFoes);
	}

	private ArrayList<String> loadCSV(String filePath) // reading database
			throws IOException {
		ArrayList<String> data = new ArrayList<String>();
		String currentLine = "";
		FileReader fileReader = new FileReader(filePath);
		BufferedReader br = new BufferedReader(fileReader);
		while ((currentLine = br.readLine()) != null) {
			data.add(currentLine);
		}

		return data;
	}

	private void loadAttacks(String filePath) throws IOException { // load
																	// attacks
		attacks = new ArrayList<Attack>();
		ArrayList<String> process = loadCSV(filePath);
		for (int i = 0; i < process.size(); i++) {
			String[] line = (process.get(i)).split(",");
			if (line[0].equals("SA"))
				attacks.add(new SuperAttack(line[1], Integer.parseInt(line[2])));
			else if (line[0].equals("UA"))
				attacks.add(new UltimateAttack(line[1], Integer
						.parseInt(line[2])));
			else if (line[0].equals("MC"))
				attacks.add(new MaximumCharge());
			else
				attacks.add(new SuperSaiyan());
		}

	}

	private ArrayList<SuperAttack> intializeSuperAttacks( // searching for super
															// attacks in
															// attacks
			String[] foesSuperAttacks) {
		ArrayList<SuperAttack> Sattacks = new ArrayList<SuperAttack>();
		for (int j = 0; j < foesSuperAttacks.length; j++) {
			String name = foesSuperAttacks[j];
			for (int k = 0; k < attacks.size(); k++) {
				Attack a = attacks.get(k);
				if (name.equals(a.getName())) {
					if (a instanceof SuperAttack || a instanceof MaximumCharge)
						Sattacks.add((SuperAttack) a);
				}
			}
		}
		return Sattacks;
	}

	private ArrayList<UltimateAttack> intializeUltimateattacks( // searching for
																// ultimate
																// attacks in
																// attacks
			String[] foesUltimateAttacks) {
		ArrayList<UltimateAttack> Uattacks = new ArrayList<UltimateAttack>();
		for (int j = 0; j < foesUltimateAttacks.length; j++) {
			String name = foesUltimateAttacks[j];
			for (int k = 0; k < attacks.size(); k++) {
				Attack a = attacks.get(k);
				if (name.equals(a.getName())) {
					if (a instanceof UltimateAttack || a instanceof SuperSaiyan)
						Uattacks.add((UltimateAttack) a);
				}
			}
		}
		return Uattacks;

	}

	private void loadFoes(String filePath) throws IOException { // load foes
		weakFoes = new ArrayList<NonPlayableFighter>();
		strongFoes = new ArrayList<NonPlayableFighter>();
		ArrayList<SuperAttack> foeS;
		ArrayList<UltimateAttack> foeU;
		ArrayList<String> process = loadCSV(filePath);
		for (int i = 0; i < process.size(); i += 3) {
			String[] foesData = (process.get(i)).split(",");

			if ((process.get(i + 1)).length() != 0) {
				String[] foesSuperAttacks = (process.get(i + 1)).split(",");
				foeS = intializeSuperAttacks(foesSuperAttacks);
			} else
				foeS = new ArrayList<SuperAttack>();

			if ((process.get(i + 2)).length() != 0) {
				String[] foesUltimateAttacks = (process.get(i + 2)).split(",");
				foeU = intializeUltimateattacks(foesUltimateAttacks);
			} else
				foeU = new ArrayList<UltimateAttack>();

			NonPlayableFighter x = new NonPlayableFighter(foesData[0],
					Integer.parseInt(foesData[1]),
					Integer.parseInt(foesData[2]),
					Integer.parseInt(foesData[3]),
					Integer.parseInt(foesData[4]),
					Integer.parseInt(foesData[5]),
					Integer.parseInt(foesData[6]),
					Boolean.parseBoolean(foesData[7]), foeS, foeU);

			if (x.isStrong())
				strongFoes.add(x);
			else
				weakFoes.add(x);
		}

	}

	private void loadDragons(String filePath) throws IOException { // load
																	// dragons
		dragons = new ArrayList<Dragon>();
		ArrayList<String> process = loadCSV(filePath);
		for (int i = 0; i < process.size(); i += 3) {
			String[] dragonsData = (process.get(i)).split(",");
			String[] dragonSattack = (process.get(i + 1)).split(",");
			String[] dragonUattack = (process.get(i + 2)).split(",");
			ArrayList<SuperAttack> dragonS = intializeSuperAttacks(dragonSattack);
			ArrayList<UltimateAttack> dragonU = intializeUltimateattacks(dragonUattack);
			dragons.add(new Dragon(dragonsData[0], dragonS, dragonU, Integer
					.parseInt(dragonsData[1]), Integer.parseInt(dragonsData[2])));
		}
	}

	public Player getPlayer() {
		return player;
	}

	public World getWorld() {
		return world;
	}

	public ArrayList<NonPlayableFighter> getStrongFoes() {
		return strongFoes;
	}

	public ArrayList<NonPlayableFighter> getWeakFoes() {
		return weakFoes;
	}

	public ArrayList<Attack> getAttacks() {
		return attacks;
	}

	public ArrayList<Dragon> getDragons() {
		return dragons;
	}

}
