package dragonball.model.world;

import dragonball.model.character.fighter.*;

import java.util.*;

import dragonball.model.cell.*;

public class World {
	private Cell[][] map;
	private int playerColumn;
	private int playerRow;

	public World() {
		map = new Cell[10][10];
		playerColumn = 9;
		playerRow = 9;

	}

	public static int randomize(int size) {
		return (int) (Math.random() * size);
	}

	public boolean isValid(int x, int y) {
		return (x + y != 18) && (x + y != 0) && x >= 0 && x < 10 && y >= 0
				&& y < 10 && (map[x][y] == null);
	}

	public void spreadWeakFoes(ArrayList<NonPlayableFighter> weakFoes) {
		for (int i = 0; i < 15; i++) {
			int w = randomize(weakFoes.size());
			int wx, wy;
			do {
				wx = randomize(10);
				wy = randomize(10);
			} while (!isValid(wx, wy));
			map[wx][wy] = new FoeCell(weakFoes.get(w));
		}
	}

	public void spreadSenzubeans() {
		int num = randomize(3) + 3;
		for (int i = 0; i < num; i++) {
			int sx, sy;
			do {
				sx = randomize(10);
				sy = randomize(10);
			} while (!isValid(sx, sy));
			map[sx][sy] = new CollectibleCell(Collectible.SENZU_BEAN);
		}
	}

	public void layDragonball() {
		int dx, dy;
		do {
			dx = randomize(10);
			dy = randomize(10);
		} while (!isValid(dx, dy));
		map[dx][dy] = new CollectibleCell(Collectible.DRAGON_BALL);
	}

	public void fill() {
		for (int i = 0; i < 10; i++) {
			for (int j = 0; j < 10; j++) {
				if (isValid(i, j))
					map[i][j] = new EmptyCell();
			}
		}
	}

	public void generateMap(ArrayList<NonPlayableFighter> weakFoes,
			ArrayList<NonPlayableFighter> strongFoes) {
		int s = randomize(strongFoes.size());
		map[0][0] = new FoeCell(strongFoes.get(s));
		map[9][9] = new EmptyCell();
		spreadWeakFoes(weakFoes);
		spreadSenzubeans();
		layDragonball();
		fill();
	}

	public String toString() {
		String output = "";
		for (int i = 0; i < 10; i++) {
			for (int j = 0; j < 10; j++) {
				output += map[i][j].toString();
				if (j != 10)
					output += " ";
			}
			output += "\n";
		}
		return output;
	}

	public Cell[][] getMap() {
		return map;
	}

	public int getPlayerColumn() {
		return playerColumn;
	}

	public int getPlayerRow() {
		return playerRow;
	}

}
