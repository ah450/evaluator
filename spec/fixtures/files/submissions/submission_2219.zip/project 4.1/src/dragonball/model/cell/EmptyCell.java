package dragonball.model.cell;

public class EmptyCell extends Cell{
   
   public EmptyCell(){
	  
   }
  public String toString(){
	  return "[ ]";
  }
}
