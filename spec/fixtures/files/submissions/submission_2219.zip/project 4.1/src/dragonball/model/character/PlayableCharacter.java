package dragonball.model.character;

public interface PlayableCharacter {

}
