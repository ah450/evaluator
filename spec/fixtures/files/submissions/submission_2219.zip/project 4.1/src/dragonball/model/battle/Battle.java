package dragonball.model.battle;

import dragonball.model.character.fighter.NonPlayableFighter;
import dragonball.model.character.fighter.PlayableFighter;

public class Battle {
	private BattleOpponent me;
	private BattleOpponent foe;
	private BattleOpponent currentOpponent;

	public Battle(BattleOpponent me, BattleOpponent foe) {
		this.me = (PlayableFighter) me;
		this.foe = (NonPlayableFighter) foe;
		me.setHealthPoints(me.getMaxHealthPoints());
		me.setStamina(me.getMaxStamina());
		me.setKi(0);
		foe.setHealthPoints(foe.getMaxHealthPoints());
		foe.setStamina(foe.getMaxStamina());
		foe.setKi(0);

	}

	public BattleOpponent getMe() {
		return me;
	}

	public BattleOpponent getFoe() {
		return foe;
	}

	public BattleOpponent getCurrentOpponent() {
		return currentOpponent;
	}

}
