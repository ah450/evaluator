package dragonball.model.game;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;

import dragonball.model.attack.Attack;
import dragonball.model.attack.MaximumCharge;
import dragonball.model.attack.SuperAttack;
import dragonball.model.attack.SuperSaiyan;
import dragonball.model.attack.UltimateAttack;
import dragonball.model.character.fighter.NonPlayableFighter;
import dragonball.model.dragon.Dragon;
import dragonball.model.player.Player;
import dragonball.model.world.World;

public class Game {

	private Player player;
	private World world;
	private ArrayList<NonPlayableFighter> weakFoes;
	private ArrayList<NonPlayableFighter> strongFoes;
	private ArrayList<Attack> attacks;
	private ArrayList<Dragon> dragons;

	public Game() throws IOException {
		player = new Player("");
		attacks=new ArrayList<Attack>();
		weakFoes = new ArrayList<NonPlayableFighter>();
		strongFoes = new ArrayList<NonPlayableFighter>();
		dragons=new ArrayList<Dragon>();
		loadAttacks("Database-Attacks.csv");
		loadFoes("Database-Foes.csv");
		loadDragons("Database-Dragons.csv");
		world = new World();
		world.generateMap(weakFoes, strongFoes);

	}

	private ArrayList<String> loadCSV(String filePath) throws IOException {
		ArrayList<String> store = new ArrayList<String>();
		String currentLine = "";
		FileReader fileReader = new FileReader(filePath);
		BufferedReader br = new BufferedReader(fileReader);
		while ((currentLine = br.readLine()) != null) {
			store.add(currentLine);
		}
		return store;

	}

	private void loadAttacks(String filePath) throws IOException {
		ArrayList<String> storeAttacks = loadCSV(filePath);
		for (int i = 0; i < storeAttacks.size(); i++) {
			String[] a = storeAttacks.get(i).split(",");
			if (a[0].equals("SA"))
				attacks.add(new SuperAttack(a[1], Integer.parseInt(a[2])));
			else if (a[0].equals("UA"))
				attacks.add(new UltimateAttack(a[1], Integer.parseInt(a[2])));
			else if (a[0].equals("MC"))
				attacks.add(new MaximumCharge());
			else if (a[0].equals("SS"))
				attacks.add(new SuperSaiyan());

		}

	}

	private void loadFoes(String filePath) throws IOException {
		ArrayList<String> storeFoes = loadCSV(filePath);
		ArrayList<String[]> x = new ArrayList<String[]>();
		for (int i = 0; i < storeFoes.size(); i++) {
			String[]a=storeFoes.get(i).split(",");
			x.add(a);
		}
		while (x.size() != 0) {
			String[] a1 = x.remove(0);
			String[] a2 = x.remove(0);
			String[] a3 = x.remove(0);
			ArrayList<SuperAttack> storeS = new ArrayList<SuperAttack>();

			for (int j = 0; j < a2.length; j++)
				{
				if(a2[j].equals("Maximum Charge"))
					storeS.add(new MaximumCharge());
				else if(a2[0].length()==0)
					break;
				else
				storeS.add(new SuperAttack(a2[j], getdamagevalue(a2[j])));
				}

			ArrayList<UltimateAttack> storeU = new ArrayList<UltimateAttack>();
			for (int y = 0; y < a3.length; y++)
			{	
			
	       if(a3[0].length()==0)
					break;
			else
				storeU.add(new UltimateAttack(a3[y], getdamagevalue(a3[y])));
	       
			}
			System.out.println(storeS.size()+" "+storeU.size());
			if (a1[7].equals("TRUE"))
				strongFoes.add(new NonPlayableFighter(a1[0], Integer.parseInt(a1[1]), Integer.parseInt(a1[2]),
						Integer.parseInt(a1[3]), Integer.parseInt(a1[4]), Integer.parseInt(a1[5]),
						Integer.parseInt(a1[6]), true, storeS, storeU));

			else
				weakFoes.add(new NonPlayableFighter(a1[0], Integer.parseInt(a1[1]), Integer.parseInt(a1[2]),
						Integer.parseInt(a1[3]), Integer.parseInt(a1[4]), Integer.parseInt(a1[5]),
						Integer.parseInt(a1[6]),false, storeS, storeU));
		}

	}

	public int getdamagevalue(String n) {
		for (int i = 0; i < attacks.size(); i++) {
			if (n.equals(attacks.get(i).getName()))
				return attacks.get(i).getDamage();
		}
		return 0;
	}

	private void loadDragons(String filePath) throws IOException {
		ArrayList<String> storeDragons = loadCSV(filePath);
		ArrayList<String[]> x = new ArrayList<String[]>();
		for (int i = 0; i < storeDragons.size(); i++) {
			x.add(storeDragons.get(i).split(","));

		}
		while (x.size() != 0) {
			String[] a1 = x.remove(0);
			String[] a2 = x.remove(0);
			String[] a3 = x.remove(0);
			ArrayList<SuperAttack> storeS = new ArrayList<SuperAttack>();

			for (int j = 0; j < a2.length; j++)
				{storeS.add(new SuperAttack(a2[j], getdamagevalue(a2[j])));}

			ArrayList<UltimateAttack> storeU = new ArrayList<UltimateAttack>();
			for (int y = 0; y < a3.length; y++)
				{storeU.add(new UltimateAttack(a3[y], getdamagevalue(a3[y])));}
			dragons.add(new Dragon(a1[0], storeS, storeU, Integer.parseInt(a1[1]), Integer.parseInt(a1[2])));
		}
	}

	public Player getPlayer() {
		return player;
	}

	public World getWorld() {
		return world;
	}

	public ArrayList<NonPlayableFighter> getWeakFoes() {
		return weakFoes;
	}

	public ArrayList<NonPlayableFighter> getStrongFoes() {
		return strongFoes;
	}

	public ArrayList<Attack> getAttacks() {
		return attacks;
	}

	public ArrayList<Dragon> getDragons() {
		return dragons;
	}

	
}
