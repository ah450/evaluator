package dragonball.model.attack;

public class UltimateAttack extends Attack{

	public UltimateAttack(String name, int damage) {
		super(name, damage);
		
	}

}
