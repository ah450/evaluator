package dragonball.model.world;

import java.util.ArrayList;
import java.util.Random;

import dragonball.model.cell.Cell;
import dragonball.model.cell.Collectible;
import dragonball.model.cell.CollectibleCell;
import dragonball.model.cell.EmptyCell;
import dragonball.model.cell.FoeCell;
import dragonball.model.character.fighter.NonPlayableFighter;

public class World {
	private Cell[][] map;
	private int playerColumn;
	private int playerRow;
	public World(){
		map = new Cell[10][10];
		
	}
	public void generateMap(ArrayList<NonPlayableFighter> weakFoes, ArrayList<NonPlayableFighter> strongFoes){
		int x;
		int y;
		int z;
		for(int i = 0; i < 10; i++){
			for(int j = 0; j < 10; j++)
				map[i][j] = new EmptyCell();
		}
	
				for(int i=0;i<15;i++){
					 x=((int)(Math.random()*10));
					 y=((int)(Math.random()*10));
					z=((int)(Math.random()*weakFoes.size()));
					if(!map[x][y].toString().equals("[ ]"))
					{
						while(!map[x][y].toString().equals("[ ]")){
							x=((int)(Math.random()*10));
						 y=((int)(Math.random()*10));
						 z=((int)(Math.random()*weakFoes.size()));
						 }
						map[x][y]=new FoeCell(weakFoes.get(z));
					}
					else
						map[x][y]=new FoeCell(weakFoes.get(z));
				}
				//Random sb = new Random();
				int sbresult = ((int)((Math.random()*3)+3));
				for(int i=0;i<sbresult;i++){
					x=((int)(Math.random()*10));
					 y=((int)(Math.random()*10));
					if(map[x][y].toString().equals("[ ]"))
						map[x][y]=new CollectibleCell(Collectible.SENZU_BEAN);
					else{
						while(!(map[x][y].toString()).equals("[ ]")){
							x=((int)(Math.random()*10));
							 y=((int)(Math.random()*10));
						}
						map[x][y]=new CollectibleCell(Collectible.SENZU_BEAN);
					}
				}
				x=((int)(Math.random()*10));
				 y=((int)(Math.random()*10));
				if(map[x][y].toString().equals("[ ]"))
					map[x][y]=new CollectibleCell(Collectible.DRAGON_BALL);
				else{
					while(!(map[x][y].toString()).equals("[ ]"))
					{
						x=((int)(Math.random()*10));
						 y=((int)(Math.random()*10));
					}
					map[x][y]=new CollectibleCell(Collectible.DRAGON_BALL);
				}
				map[9][9]=new EmptyCell();
				map [0][0]=new FoeCell(strongFoes.get(((int)(Math.random()*(strongFoes.size())))));
				
				
	}
	
		
	
	public Cell[][] getMap() {
		return map;
	}
	public int getPlayerColumn() {
		return playerColumn;
	}
	public int getPlayerRow() {
		return playerRow;
	}
	
	public String toString(){
		String s="";
		for(int i=0;i<map.length;i++){
			for(int j=0;j<map[i].length;j++){
				s=""+map[i][j];
			}
			s=s+"\n";
		}
		return s;
		
}
}