package dragonball.model.cell;

public class EmptyCell extends Cell{

	public EmptyCell(){
		super();
	}
	public String toString(){
		
		return"[ ]";
	}
}
