package dragonball.model.attack;

public class SuperAttack extends Attack{

	public SuperAttack(String name, int damage) {
		super(name, damage);
		
	}

}
