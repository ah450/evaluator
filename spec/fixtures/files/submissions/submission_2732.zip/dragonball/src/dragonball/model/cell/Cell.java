package dragonball.model.cell;

public abstract class Cell {
	public Cell(){
		
	}
	public abstract String toString();

}
