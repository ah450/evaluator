package dragonball.model.attack;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class UltimateAttack extends Attack{
	public UltimateAttack(String name , int damage){
		super(name , damage);
	}

}
