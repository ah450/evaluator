package dragonball.model.cell;
import dragonball.model.character.fighter.*;
public class FoeCell extends Cell{
	
	public FoeCell(NonPlayableFighter foe){
		this.foe =foe;
	}
	
	private NonPlayableFighter foe;

	public NonPlayableFighter getFoe() {
		return foe;
	}
	
	public String toString(){
		if(foe.isStrong()==true)
			return"[b]" ;
		else 
			return "[w]" ;
	}
	

}
