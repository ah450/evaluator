package dragonball.model.world;
import java.util.*;
import dragonball.model.cell.*;
import dragonball.model.character.fighter.*;


public class World {
	private Cell[][] map;
	private int playerColumn;
	private int playerRow;
	
	public Cell[][] getMap() {
		return map;
	}

	public int getPlayerColumn() {
		return playerColumn;
	}

	public int getPlayerRow() {
		return playerRow;
	}

	public World(){
		map = new Cell[10][10];
	}
	public static int generateRandom(int size){
		int x = (int) (  Math.random() * size ) ;
		return x ;
	}
	public static int generateSBR(){
		int x = (int)( (Math.random()*3) + 3 );
		return x;
	}	
	public static boolean RLocate(int x , int y){
		
		boolean check = true;
		if(x==0 && y==0)
			check = false;
		if(x==9 && y ==9){
			check = false ;
		}else{
			check = true;
		}
				
		return check ;
	}
	
	public void generateMap(ArrayList<NonPlayableFighter> weakFoes, ArrayList<NonPlayableFighter> strongFoes){
		for(int i = 0 ; i < 10 ; i ++){
			for(int j = 0 ; j< 10 ; j++){
				map[i][j] = new EmptyCell();
			}
		}
		
		
		int bossNO = generateRandom(strongFoes.size());
		NonPlayableFighter z = strongFoes.get(bossNO);
		map[0][0] = new FoeCell(z);
		
		
		for(int WeakFoeCounter = 0 ; WeakFoeCounter <= 15 ; WeakFoeCounter++){
			int x = (int)((Math.random()*10)); 
			int y = (int)((Math.random()*10));
			boolean check = true ;
			while(check){
				boolean see = RLocate(x,y);
				if(see == false){
					 x = (int)((Math.random()*10)); 
					 y = (int)((Math.random()*10));
				}else{
					check = false ;
				}
				
			}
			boolean check2 = true ;
			
			while(check2){
				if( map[x][y] instanceof EmptyCell ){
					int WeakFoeNO = generateRandom(weakFoes.size());
					NonPlayableFighter u = weakFoes.get(WeakFoeNO);
					map[x][y] = new FoeCell(u);
					check2 = false ;
				}else{
					x = (int)((Math.random()*10)); 
					y = (int)((Math.random()*10));
					boolean check3 = true;
					while(check3){
						boolean see1 = RLocate(x,y);
						if(see1 == false){
							x = (int)((Math.random()*10)); 
							y = (int)((Math.random()*10));
						}else{
							check3 = false;
						}
					}
				}
			}
			
		}
		int SBNumber = generateSBR();
		for(int SenzuBeanCounter = 0 ; SenzuBeanCounter<=SBNumber; SenzuBeanCounter++){
			int x = (int)((Math.random()*10)); 
			int y = (int)((Math.random()*10));
			boolean check=true;
			while(check){
				boolean see = RLocate(x,y);
				if(see==false){
					x = (int)((Math.random()*10)); 
					y = (int)((Math.random()*10));
				}else{
					check = false;
				}
			}
			boolean check2 = true;
			while(check2){
				if(map[x][y] instanceof EmptyCell){
					
					map[x][y] = new CollectibleCell(Collectible.SENZU_BEAN);
					check2= false;
				}
				else{
					x = (int)((Math.random()*10)); 
					y = (int)((Math.random()*10));
					boolean check3 = true;
					while(check3){
						boolean see1 = RLocate(x, y);
						if(see1 == false){
							x = (int)((Math.random()*10)); 
							y = (int)((Math.random()*10));
						}else{
							check3 = false ;
						}
					}
				}
			}
			
			
		}
		
		for(int DBCounter = 0 ; DBCounter<=1; DBCounter++){
			int x = (int)((Math.random()*10)); 
			int y = (int)((Math.random()*10));
			boolean check=true;
			while(check){
				boolean see = RLocate(x,y);
				if(see == false){
					x = (int)((Math.random()*10)); 
					y = (int)((Math.random()*10));
				}else{
					check = false;
				}
			}
			boolean check2 = true;
			while(check2){
				if(map[x][y] instanceof EmptyCell){
					map[x][y] = new CollectibleCell(Collectible.DRAGON_BALL);
					check2 =false;
				}else{
					x = (int)((Math.random()*10)); 
					y = (int)((Math.random()*10));
					boolean check3 = true ;
					while(check3){
						boolean see1 = RLocate(x, y);
						if(see1 == false){
							x = (int)((Math.random()*10)); 
							y = (int)((Math.random()*10));
						}else{
							check3 = false ;
						}
					}
				}
			}
			
			
		}
		
	
		
	}
	
	public String toString(){
		String output = "";
		for(int i =0 ; i<10 ; i++){
			for(int j =0 ; j<10 ; j++){
				output = output + map[i][j].toString() ;
			}
		}
		return output;
	}

}
