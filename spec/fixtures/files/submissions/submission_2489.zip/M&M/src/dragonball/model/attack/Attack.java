package dragonball.model.attack;

public abstract class Attack {
	private String name;
	private int damage;
	public String getName() {
		return name;
	}
	public int getDamage() {
		return damage;
	}
	public Attack(String name, int damage){
		this.name = name ;
		this.damage = damage ;
	}
	
}
