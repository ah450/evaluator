package dragonball.model.attack;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;


public class SuperAttack extends Attack{
	public SuperAttack(String name , int damage){
		super (name,damage);
	}

}
