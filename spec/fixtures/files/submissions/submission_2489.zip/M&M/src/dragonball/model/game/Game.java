package dragonball.model.game;
import java.util.*;
import dragonball.model.player.Player;
import dragonball.model.character.fighter.*;
import dragonball.model.attack.*;
import dragonball.model.dragon.*;
import dragonball.model.world.World;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;


public class Game {
	private Player player;
	private World world;
	private ArrayList<NonPlayableFighter> weakFoes;
	private ArrayList<NonPlayableFighter> strongFoes;
	private ArrayList<Attack> attacks;
	private ArrayList<Dragon> dragons;
	
	public Player getPlayer() {
		return player;
	}

	public World getWorld() {
		return world;
	}

	public ArrayList<NonPlayableFighter> getWeakFoes() {
		return weakFoes;
	}

	public ArrayList<NonPlayableFighter> getStrongFoes() {
		return strongFoes;
	}

	public ArrayList<Attack> getAttacks() {
		return attacks;
	}

	public ArrayList<Dragon> getDragons() {
		return dragons;
	}

	public Game(){
		
	}
	 	
	private ArrayList<String> loadCSV(String path) throws IOException{
		String currentLine = "";
		FileReader fileReader= new FileReader(path);
		BufferedReader br = new BufferedReader(fileReader);
		ArrayList<String> a1 = new ArrayList<String>() ;
		while ((currentLine = br.readLine()) != null) {
			a1.add(currentLine);
		}
		return a1 ;
	}
		
	
	private void loadAttacks(String filePath)  throws IOException {
		ArrayList<String> a = loadCSV(filePath);
		
		while(!a.isEmpty()){
			String s = a.remove(0);
			String [] output = s.split(",");
			if(output[0].equals("SA")){
				SuperAttack sa = new SuperAttack( output[1] ,  Integer.parseInt(output[2]) );
				attacks.add(sa);
			}else if(output[0].equals("UA")){
				UltimateAttack ua = new UltimateAttack(output[1], Integer.parseInt(output[2]));
				attacks.add(ua);
			}else if(output[0].equals("MC")){
				MaximumCharge mc = new MaximumCharge();
				attacks.add(mc);
			}else if(output[0].equals("SS")){
				SuperSaiyan ss = new SuperSaiyan();
				attacks.add(ss);
			}
			
			
			
			
		}
	}
	
	private void loadFoes(String filePath) throws IOException {
		ArrayList<String> foes = loadCSV(filePath);
		
		ArrayList<Attack> x = this.getAttacks();
		
		while(!foes.isEmpty()){
			ArrayList<SuperAttack> saIN = new ArrayList<SuperAttack>();
			ArrayList<UltimateAttack> uaIN = new ArrayList<UltimateAttack>();
			String [] d1 = (foes.remove(0)).split(",");
			String  secondL = foes.remove(1);
			String  thirdL = foes.remove(2);
		
			if(!secondL.equals("")){
				String [] d2 = secondL.split(",");
				int d2Size = d2.length;
				for(int j =0 ; j < d2Size ; j ++){
					String see = d2[j];
					for(int k = 0 ; k < x.size() ; k++){
						Attack current = x.get(k);
						if(current.getName().equals(see)){
							SuperAttack toArr = new SuperAttack(current.getName() , current.getDamage());
							saIN.add(toArr);
						}
					}	
				}
			}
			
			if(!thirdL.equals("")){
				String [] d3 = thirdL.split(",");
				int d3Size = d3.length;
				for(int j =0 ; j<d3Size ; j ++){
					String see = d3[j];
					for(int k = 0 ; k <x.size(); k++){
						Attack current = x.get(k);
						if(current.getName().equals(see)){
							UltimateAttack toArr = new UltimateAttack(current.getName() , current.getDamage());
							uaIN.add(toArr);
						}
					}
				}
			}
			
			String n = d1[0];
			int l = Integer.parseInt(d1[1]);
			int mHP = Integer.parseInt(d1[2]);
			int bDmg = Integer.parseInt(d1[3]);
			int phyDmg = Integer.parseInt(d1[4]);
			int maxK = Integer.parseInt(d1[5]);
			int maxSta = Integer.parseInt(d1[6]);
			boolean str ;
			if(d1[7].equals("TRUE")){
				str = true ;
				NonPlayableFighter toBeAdded = new NonPlayableFighter(n, l, mHP,
						bDmg, phyDmg, maxK, maxSta, str, saIN,
						uaIN);
				strongFoes.add(toBeAdded);
			}
			if(d1[7].equals("FALSE")){
				str = false ;
				NonPlayableFighter toBeAdded = new NonPlayableFighter(n, l, mHP,
						bDmg, phyDmg, maxK, maxSta, str, saIN,
						uaIN);
				weakFoes.add(toBeAdded);
			}
			
			
			
		}
		
	}
	private void loadDragons(String filePath)throws IOException{
		ArrayList<String>dra  = loadCSV(filePath);
	
	
		ArrayList<Attack> x = this.getAttacks();
		
		while(!dra.isEmpty()){
			ArrayList<SuperAttack> saIN = new ArrayList<SuperAttack>() ;
			ArrayList<UltimateAttack> uaIN = new ArrayList<UltimateAttack>();
			String [] d1 = (dra.remove(0)).split(",");
			String [] d2 = (dra.remove(1)).split(",");
			String [] d3 = (dra.remove(2)).split(",");
			int d2Size = d2.length;
			int d3Size = d3.length;
			
			for(int k = 0 ; k < d2Size ; k++){
				String toSee = d2[k];
				
				for(int t = 0 ; t < x.size() ; t++){
					Attack tmp = x.get(t);
					if(tmp.getName().equals(toSee) ){
						SuperAttack inArr = new SuperAttack(tmp.getName(), tmp.getDamage());
						saIN.add(inArr);
						break;
					}
				}
				
			}
			
			for(int k =0 ; k < d3Size ; k++){
				String toSee1 = d3[k];
				
				for(int t=0 ; t<x.size() ; t++){
					Attack tmp = x.get(t);
					if(tmp.getName().equals(toSee1)){
						UltimateAttack inArr = new UltimateAttack(tmp.getName(), tmp.getDamage());
						uaIN.add(inArr);
						break;
					}
					
				}
				
			}
			
			
			Dragon dr = new Dragon(d1[0], saIN, uaIN, Integer.parseInt(d1[1]), Integer.parseInt(d1[2]) );
			dragons.add(dr);
			
		}
		
		
		
	}
	
}
