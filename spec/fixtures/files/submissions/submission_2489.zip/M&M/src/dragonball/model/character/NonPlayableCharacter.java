package dragonball.model.character;

public interface NonPlayableCharacter {

}
