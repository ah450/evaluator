package dragonball.model.battle;

public interface BattleOpponent {

}
