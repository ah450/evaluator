package dragonball.model.cell;

public abstract class Cell {
	
	public abstract String toString();
	

}
