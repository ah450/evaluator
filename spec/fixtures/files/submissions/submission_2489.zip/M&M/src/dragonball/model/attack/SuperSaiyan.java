package dragonball.model.attack;


public class SuperSaiyan extends UltimateAttack{
	public SuperSaiyan(){
		super("SuperSaiyan" , 0);
	}

}
