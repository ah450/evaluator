package dragonball.model.character.fighter;

import java.util.ArrayList;

import dragonball.model.attack.SuperAttack;
import dragonball.model.attack.UltimateAttack;

public class Namekian extends PlayableFighter{
public Namekian(String name){
	super(name);
	this.setName(name);
	this.setLevel(1);
	this.setXp(0);
	this.setTargetXp(10);
	this.setAbilityPoints(0);
	this.setKi(this.getKi());
	this.setMaxKi(getMaxKi());
	this.setMaxStamina(getStamina());
	this.setSuperAttacks(getSuperAttacks());
	this.setUltimateAttacks(getUltimateAttacks());
	this.setBlastDamage(0);
	this.setPhysicalDamage(50);
	this.setMaxHealthPoints(1350);
	this.setMaxKi(3);
	this.setMaxStamina(5);
}
	public Namekian(String name,  int maxHealthPoints,
			int blastDamage, int physicalDamage, int maxKi, int maxStamina,
			ArrayList<SuperAttack> superAttacks,
			ArrayList<UltimateAttack> ultimateAttacks) {
		super(name, maxHealthPoints, blastDamage, physicalDamage, maxKi,
				maxStamina, superAttacks, ultimateAttacks);
		
		
	}
	public Namekian(String name, int level, int xp, int targetXp,
			int maxHealthPoints, int blastDamage, int physicalDamage,
			int abilityPoints, int maxKi, int maxStamina,
			ArrayList<SuperAttack> superAttacks,
			ArrayList<UltimateAttack> ultimateAttacks) {
		super(name, level, xp, targetXp, maxHealthPoints, blastDamage, physicalDamage,
				abilityPoints, maxKi, maxStamina, superAttacks, ultimateAttacks);
		this.setLevel(level);
		this.setXp(xp);
		this.setTargetXp(targetXp);
		this.setAbilityPoints(abilityPoints);
	}
	@Override
	public void onAttackerTurn() {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void onDefenderTurn() {
		// TODO Auto-generated method stub
		
	}
}
