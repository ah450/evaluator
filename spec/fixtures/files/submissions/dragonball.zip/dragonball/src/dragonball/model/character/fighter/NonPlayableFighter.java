package dragonball.model.character.fighter;

import java.util.ArrayList;

import dragonball.model.attack.SuperAttack;
import dragonball.model.attack.UltimateAttack;
import dragonball.model.character.NonPlayableCharacter;

public class NonPlayableFighter extends Fighter implements NonPlayableCharacter, Cloneable  {
	public NonPlayableFighter(String name, int level, int maxHealthPoints,
			int blastDamage, int physicalDamage, int maxKi, int maxStamina,
			ArrayList<SuperAttack> superAttacks,
			ArrayList<UltimateAttack> ultimateAttacks) {
		
		
		super(name, level, maxHealthPoints, blastDamage, physicalDamage, maxKi,
				maxStamina, superAttacks, ultimateAttacks);
	}
	
	private boolean strong;
	
//	public NonPlayableFighter clone() throws CloneNotSupportedException{
//		NonPlayableFighter x = (NonPlayableFighter) super.clone();
//		ArrayList<SuperAttack> timor = new ArrayList<SuperAttack>();
//		for (int i = 0; i < timor.size(); i++) {
//			timor.add(x.getSuperAttacks().get(i));
//		}
//		timor.
//		
//		
//		
//		return x;
//	}
	
	public boolean isStrong() {
		return strong;
	}
	
	public NonPlayableFighter(String name, int level,int maxHealthPoints, int blastDamage,
			int physicalDamage, int maxKi, int maxStamina, boolean strong, ArrayList<SuperAttack>
			superAttacks, ArrayList<UltimateAttack> ultimateAttacks){
		super(name,level,maxHealthPoints,blastDamage,physicalDamage,maxKi,maxStamina,superAttacks,ultimateAttacks);
		this.strong=strong;
	}

	@Override
	public void onAttackerTurn() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onDefenderTurn() {
		// TODO Auto-generated method stub
		
	}
	

}
