package dragonball.model.cell;

public enum Collectible {
	SENZU_BEAN,DRAGON_BALL;
	public String toString(){
	return null;
}
}
