package dragonball.model.attack;

import dragonball.model.battle.BattleOpponent;

public class PhysicalAttack extends Attack {

	public PhysicalAttack(String name, int damage) {
		super(name, damage);
		
	}public PhysicalAttack(){
		super("physicalattack",50);
		
		
	}
	@Override
	int getAppliedDamage(BattleOpponent attacker) {
		// TODO Auto-generated method stub
		return 0;
	}

}
