package dragonball.model.character;

import java.util.ArrayList;

import dragonball.model.attack.SuperAttack;
import dragonball.model.attack.UltimateAttack;

public interface PlayableCharacter {
	void onAttackerTurn();
}