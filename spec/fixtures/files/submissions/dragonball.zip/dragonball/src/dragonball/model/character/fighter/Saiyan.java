package dragonball.model.character.fighter;

import java.util.ArrayList;

import dragonball.model.attack.SuperAttack;
import dragonball.model.attack.UltimateAttack;

public class Saiyan extends PlayableFighter {
	private boolean transformed=false;
	public boolean isTransformed() {
		return transformed;
	}
	public void setTransformed(boolean transformed) {
		this.transformed = transformed;
	}
	public Saiyan(String name,  int maxHealthPoints, int blastDamage,
			int physicalDamage, int maxKi, int maxStamina,
			ArrayList<SuperAttack> superAttacks,
			ArrayList<UltimateAttack> ultimateAttacks) {
		super(name, maxHealthPoints, blastDamage, physicalDamage, maxKi,
				maxStamina, superAttacks, ultimateAttacks);
		
	}
	public Saiyan(String name, int level, int xp, int targetXp,
			int maxHealthPoints, int blastDamage, int physicalDamage,
			int abilityPoints, int maxKi, int maxStamina,
			ArrayList<SuperAttack> superAttacks,
			ArrayList<UltimateAttack> ultimateAttacks) {
		super(name, level, xp, targetXp, maxHealthPoints, blastDamage, physicalDamage,
				abilityPoints, maxKi, maxStamina, superAttacks, ultimateAttacks);
		this.setLevel(level);
		this.setXp(xp);
		this.setTargetXp(targetXp);
		this.setAbilityPoints(abilityPoints);
		this.setTransformed(transformed);
	}
	public Saiyan(String name){
		super(name);
		this.setName(name);
		this.setLevel(1);
		this.setXp(0);
		this.setTargetXp(10);
		this.setAbilityPoints(0);
		this.setKi(this.getKi());
		this.setMaxKi(getMaxKi());
		this.setMaxStamina(getStamina());
		this.setSuperAttacks(getSuperAttacks());
		this.setUltimateAttacks(getUltimateAttacks());
		this.setBlastDamage(150);
		this.setPhysicalDamage(100);
		this.setMaxHealthPoints(1000);
		this.setMaxKi(5);
		this.setMaxStamina(3);
		
	}
	@Override
	public void onAttackerTurn() {
		// TODO Auto-generated method stub
		setStamina(getStamina()+1);
		setKi(getKi()-1);
		if(getKi()==0){
			setTransformed(false);
			setStamina(0);
		}
	}
	@Override
	public void onDefenderTurn() {
		// TODO Auto-generated method stub
		setStamina(getStamina()+1);
		setKi(getKi()-1);
		if(getKi()==0){
			setTransformed(false);
			setStamina(0);
		}
	}
}
