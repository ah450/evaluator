package dragonball.model.game;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import dragonball.model.attack.Attack;
import dragonball.model.attack.MaximumCharge;
import dragonball.model.attack.SuperAttack;
import dragonball.model.attack.SuperSaiyan;
import dragonball.model.attack.UltimateAttack;
import dragonball.model.battle.BattleEvent;
import dragonball.model.battle.BattleListener;
import dragonball.model.cell.Collectible;
import dragonball.model.character.fighter.NonPlayableFighter;
import dragonball.model.dragon.Dragon;
import dragonball.model.dragon.DragonWish;
import dragonball.model.player.Player;
import dragonball.model.player.PlayerListener;
import dragonball.model.world.World;
import dragonball.model.world.WorldListener;

public class Game implements PlayerListener, WorldListener , BattleListener{
	private Player player;
	private World world;
	private static ArrayList<NonPlayableFighter> weakFoes;
	private static ArrayList<NonPlayableFighter> strongFoes;
	private static ArrayList<Attack> attacks;
	private static ArrayList<Dragon> dragons;
private GameState state;
private BattleListener x;
private GameListener y;
 Player z;



	public void setX(BattleListener x) {
	this.x = x;
}


public void setY(GameListener y) {
	this.y = y;
}


	public GameState getState() {
	return state;
}


	private ArrayList<String> CSVData = new ArrayList<String>();

	public Game() throws IOException{
		weakFoes = new ArrayList<NonPlayableFighter>();
		strongFoes = new ArrayList<NonPlayableFighter>();
		attacks = new ArrayList<Attack>();
		dragons = new ArrayList<Dragon>();
		world = new World();

		loadAttacks("Database-Attacks.csv");
		loadFoes("Database-Foes.csv");
		loadDragons("Database-Dragons.csv");

		world.generateMap(weakFoes, strongFoes);
	}


	private void loadCSV(String filePath) throws IOException{

		BufferedReader fileReader = new BufferedReader(new FileReader(filePath));
		CSVData = new ArrayList<String>();
		String line="";
		while((line=fileReader.readLine())!=null){
			CSVData.add(line);
		}
		fileReader.close();
	}


	private void loadAttacks(String filePath) throws IOException{

		if(attacks.size()==0){
			loadCSV(filePath);
			for (int i = 0; i < CSVData.size(); i++) {
				String a = CSVData.get(i);
				String[]data=a.split(",");

				switch(data[0]){
				case "SA": 
					attacks.add(new SuperAttack(data[1], Integer.parseInt(data[2])));
					break;
				case "UA": 
					attacks.add(new UltimateAttack(data[1], Integer.parseInt(data[2])));
					break;
				case "MC":
					attacks.add(new MaximumCharge());
					break;
				case "SS": 
					attacks.add(new SuperSaiyan(data[1], Integer.parseInt(data[2])));
					break;
				}
			}
		}
	}



	private void loadFoes(String filePath) throws IOException{
		if(weakFoes.size()==0 && strongFoes.size()==0){

			loadCSV(filePath);

			for (int i = 0; i < CSVData.size(); i++) {
				String a = CSVData.get(i);
				String[]data=a.split(",");
				String name = data[0];
				int level = Integer.parseInt(data[1]);
				int maxHealthPoints = Integer.parseInt(data[2]);
				int blastDamage = Integer.parseInt(data[3]);
				int physicalDamage = Integer.parseInt(data[4]);
				int maxKi = Integer.parseInt(data[5]);
				int maxStamina = Integer.parseInt(data[6]);
				boolean boss = data[7].equalsIgnoreCase("true");
				i++;
				a = CSVData.get(i);
				ArrayList<SuperAttack> atks = new ArrayList<SuperAttack>(); /** attacks arraylist*/
				data=a.split(",");
				ArrayList<String> x = new ArrayList<String>();

				for (int j = 0; j < data.length; j++) 
					x.add(data[j]);
				
				for (int j = 0; j < attacks.size()-1; j++) {
					if(x.contains(attacks.get(j).getName())&& 
							(attacks.get(j) instanceof SuperAttack)){
						atks.add((SuperAttack) attacks.get(j));
					}
				}
				
				//Sort om el array, 3ashan el mot5alef ely 3amal el tests 3ayzhom sorted w el test database 
				// ely howa 3amelha mesh sorted asasan.
				
				final ArrayList<String> xTemp = x;
				atks.sort(new Comparator<SuperAttack>() {
					@Override
					public int compare(SuperAttack o1, SuperAttack o2) {
						return Integer.compare(xTemp.indexOf(o1.getName()), xTemp.indexOf(o2.getName()));
					}
				});				
				
				i++;
				a = CSVData.get(i);
				ArrayList<UltimateAttack> ulti = new ArrayList<UltimateAttack>(); /** ulti arraylist*/
				data=a.split(",");
				x = new ArrayList<String>();
				for (int j = 0; j < data.length; j++) {
					x.add(data[j]);
				}

				for (int j = 0; j < attacks.size(); j++) {
					if(x.contains(attacks.get(j).getName())&& 
							attacks.get(j).getClass().equals(UltimateAttack.class)) 
						ulti.add((UltimateAttack) attacks.get(j));
				}
				
				if(boss) 
					strongFoes.add(new NonPlayableFighter(name, level, maxHealthPoints, blastDamage, physicalDamage, maxKi, maxStamina, boss, atks, ulti));
				else 
					weakFoes.add(new NonPlayableFighter(name, level, maxHealthPoints, blastDamage, physicalDamage, maxKi, maxStamina, boss, atks, ulti));
			}
		}
	}




	private void loadDragons(String filePath) throws IOException{
		if(dragons.size()==0){
			loadCSV(filePath);

			for (int i = 0; i < CSVData.size(); i++) {
				String a = CSVData.get(i);
				String[]data=a.split(",");

				String name = data[0];
				int beans = Integer.parseInt(data[1]);
				int AP = Integer.parseInt(data[2]);

				i++;
				a = CSVData.get(i);
				ArrayList<SuperAttack> atks = new ArrayList<SuperAttack>(); /** attacks arraylist*/
				data=a.split(",");
				ArrayList<String> x = new ArrayList<String>();
				for (int j = 0; j < data.length; j++) {
					x.add(data[j]);
				}

				for (int j = 0; j < attacks.size(); j++) {
					if(x.contains(attacks.get(j).getName())&& attacks.get(j).getClass().equals(SuperAttack.class)) atks.add((SuperAttack) attacks.get(j));
				}


				i++;
				a = CSVData.get(i);
				ArrayList<UltimateAttack> ulti = new ArrayList<UltimateAttack>(); /** ulti arraylist*/
				data=a.split(",");
				x = new ArrayList<String>();
				for (int j = 0; j < data.length; j++) {
					x.add(data[j]);
				}

				for (int j = 0; j < attacks.size(); j++) {
					if(x.contains(attacks.get(j).getName())&& attacks.get(j).getClass().equals(UltimateAttack.class)) ulti.add((UltimateAttack) attacks.get(j));
				}

				dragons.add(new Dragon(name, atks, ulti, beans, AP));
			}
		}
	}

	public Player getPlayer() {
		return player;
	}
	public World getWorld() {
		return world;
	}
	public ArrayList<NonPlayableFighter> getWeakFoes() {
		return weakFoes;
	}
	public ArrayList<NonPlayableFighter> getStrongFoes() {
		return strongFoes;
	}
	public ArrayList<Attack> getAttacks() {
		return attacks;
	}
	public ArrayList<Dragon> getDragons() {
		return dragons;
	}


	public static void populateWorld() {

	}


	@Override
	public void onBattleEvent(BattleEvent e) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void onFoeEncountered(NonPlayableFighter foe) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void onCollectibleFound(Collectible collectible) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void onDragonCalled() {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void onWishChosen(DragonWish wish) {
		// TODO Auto-generated method stub
		
	}

}
