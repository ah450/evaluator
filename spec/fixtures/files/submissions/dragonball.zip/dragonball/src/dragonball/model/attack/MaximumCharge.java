package dragonball.model.attack;

public class MaximumCharge extends SuperAttack {

	public MaximumCharge(String name, int damage) {
		super(name, damage);
		// TODO Auto-generated constructor stub
	}
	public MaximumCharge(){
		super("maximumcharge",0);
	}
}
