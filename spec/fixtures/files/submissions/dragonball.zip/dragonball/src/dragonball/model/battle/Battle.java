package dragonball.model.battle;

import java.util.ArrayList;

import dragonball.model.attack.Attack;
import dragonball.model.attack.PhysicalAttack;
import dragonball.model.cell.Collectible;
import dragonball.model.character.Character;
import dragonball.model.character.fighter.Fighter;
import dragonball.model.game.Game;
import dragonball.model.game.GameListener;
import dragonball.model.player.Player;

public class Battle implements BattleListener {
	private BattleOpponent me;
	private BattleOpponent foe;
	private BattleOpponent attacker;
	private boolean meBlocking;
	private boolean foeBlocking;
	private BattleListener x;
	private GameListener y;
	public void setX(BattleListener x) {
		this.x = x;
	}
	public void setY(GameListener y) {
		this.y = y;
	}
	public ArrayList<Attack> getAssignedAttacks(){
		return null;
		
	}
	public boolean isMeBlocking() {
		return meBlocking;
	}


	public boolean isFoeBlocking() {
		return foeBlocking;
	}


	public BattleOpponent getMe() {
		return me;
	}


	public BattleOpponent getFoe() {
		return foe;
	}


	public BattleOpponent getattacker() {
		return attacker;
	}


	public Battle(BattleOpponent me, BattleOpponent foe){
		this.me=me;
		this.foe=foe;
        ((Fighter)me).setHealthPoints(300);
        ((Fighter)me).setStamina(300);
        ((Fighter)me).setKi(0);
        ((Fighter)foe).setHealthPoints(300);
        ((Fighter)foe).setStamina(300);
        ((Fighter)foe).setKi(0);
       
	
		
	}


	@Override
	public void onBattleEvent(BattleEvent e) {
		// TODO Auto-generated method stub
		
	}
	public void start(){
		
	}
	public void attack(Attack attack){
		
	}
	public void block(){
		
	}
	public void use(Player player, Collectible collectible){
		
	}
	public BattleOpponent getDefender(){
		return null;
		
	}public void play(){
		
	}
	void endTurn(){
		
	}
	void switchTurn(){
		
	}
	public void setListener(Game g) {
		// TODO Auto-generated method stub
		
	}
	public BattleOpponent getAttacker() {
		// TODO Auto-generated method stub
		return attacker;
	}
}
