package dragonball.model.world;

import java.util.ArrayList;
import java.util.Random;

import dragonball.model.cell.Cell;
import dragonball.model.cell.CellListener;
import dragonball.model.cell.Collectible;
import dragonball.model.cell.CollectibleCell;
import dragonball.model.cell.EmptyCell;
import dragonball.model.cell.FoeCell;
import dragonball.model.character.fighter.NonPlayableFighter;
import dragonball.model.game.Game;

public class World implements CellListener {
	private Cell[][] map;
	private int playerColumn;
	private int playerRow;
	WorldListener f;
	public World(){
		this.map=new Cell[10][10];
		playerColumn=9;
		playerRow=9;
		
	}
	
	public void generateMap(ArrayList<NonPlayableFighter> weakFoes, ArrayList<NonPlayableFighter> strongFoes){
		
		map[0][0] = new FoeCell(strongFoes.get((int)(Math.random()*(strongFoes.size())))); //TODO put a boss here.
		
		int foes = 0;
		while (foes < 15) {
			int x = (int) (Math.random()*10);
			int y = (int) (Math.random()*10);
			
			if(!(x==9&&y==9) && map[x][y] == null){
				map[x][y] = new FoeCell(weakFoes.get((int)(Math.random()*(weakFoes.size()))));//TODO put a weak foe here.
				foes++;
			}
			
		}
		
		
		int beans = 0;
		int beanscount = (int) (3 + Math.random()*3);
		while (beans < beanscount) {
			int x = (int) (Math.random()*10);
			int y = (int) (Math.random()*10);
			
			if(!(x==9&&y==9) && map[x][y] == null){
				map[x][y] = new CollectibleCell(Collectible.SENZU_BEAN); //TODO put a weak foe here.
				beans++;
			}
			
		}
		
		int x = (int) (Math.random()*10);
		int y = (int) (Math.random()*10);
		
		if(!(x==9&&y==9) && map[x][y] == null){
			map[x][y] = new CollectibleCell(Collectible.DRAGON_BALL); //TODO put a weak foe here.
		}
		
		
		for (int i = 0; i < map.length; i++) {
			for (int j = 0; j < map[i].length; j++) {
				if(map[i][j]==null){
					map[i][j] = new EmptyCell();
				}
			}
		}
		
	}
	
	
	public String toString(){
		return null;

	}
	
	
	void resetPlayerPosition(){
		
	}
	
	public void moveUp(){
		
	}
	
	public void moveDown(){
		
	}
		void moveRight(){
			
		}
			public void moveLeft(){
				
			}
	
	
	
	
	
	
	


	public Cell[][] getMap() {
		return map;
	}
	
	public int getPlayerColumn() {
		return playerColumn;
	}
	public int getPlayerRow() {
		return playerRow;
	}

	@Override
	public void onFoeEncountered(NonPlayableFighter foe) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onCollectibleFound(Collectible collectible) {
		// TODO Auto-generated method stub
		
	}
	

}
