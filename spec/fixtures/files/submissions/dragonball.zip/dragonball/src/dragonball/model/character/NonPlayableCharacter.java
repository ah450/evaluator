package dragonball.model.character;

public interface NonPlayableCharacter {
	void onAttackerTurn();
}
