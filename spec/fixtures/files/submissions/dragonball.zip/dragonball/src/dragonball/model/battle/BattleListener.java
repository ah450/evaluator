package dragonball.model.battle;

public interface BattleListener {
	void onBattleEvent(BattleEvent e);
}
