package dragonball.model.attack;

public class SuperSaiyan extends UltimateAttack {

	public SuperSaiyan(String name, int damage) {
		super(name, damage);
		// TODO Auto-generated constructor stub
	}
public SuperSaiyan(){
	super("SuperSaiyan",0);
}
}
