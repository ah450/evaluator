package dragonball.model.battle;

public enum BattleEventType {
	STARTED, ENDED, NEWTURN,
	ATTACK, BLOCK , USE;
}
