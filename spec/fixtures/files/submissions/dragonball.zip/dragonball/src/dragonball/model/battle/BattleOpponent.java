package dragonball.model.battle;

import java.util.ArrayList;

import dragonball.model.attack.SuperAttack;
import dragonball.model.attack.UltimateAttack;

public interface BattleOpponent {
	void onAttackerTurn();
	void onDefenderTurn();
	
	
	
	
	
	
	
	
	
			}
