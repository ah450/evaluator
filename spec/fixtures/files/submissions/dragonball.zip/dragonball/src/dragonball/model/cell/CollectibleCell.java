package dragonball.model.cell;

public class CollectibleCell extends Cell {
	private Collectible collectible;
	public Collectible getCollectible() {
		return collectible;
	}

	public CollectibleCell(Collectible collectible) {
		super();
		this.collectible = collectible;
	}

	public String toString(){
		if(collectible == collectible.DRAGON_BALL){
			return "[d]";}
		else
			return "[s]";
	}
void onStep(){
		
	}
}

