package dragonball.model.battle;

public interface BattleOpponent {
	
	public void maximizeHealthPoints();
	public void maximizeStamina();

}
