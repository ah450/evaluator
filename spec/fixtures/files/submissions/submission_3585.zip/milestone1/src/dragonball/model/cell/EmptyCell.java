package dragonball.model.cell;

public class EmptyCell extends Cell {
	public String toString()
	{
		return "[ ]";
	}

}
