package dragonball.model.game;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

import dragonball.model.attack.Attack;
import dragonball.model.attack.MaximumCharge;
import dragonball.model.attack.SuperAttack;
import dragonball.model.attack.SuperSaiyan;
import dragonball.model.attack.UltimateAttack;
import dragonball.model.character.fighter.NonPlayableFighter;
import dragonball.model.dragon.Dragon;
import dragonball.model.player.Player;
import dragonball.model.world.World;

public class Game {
	private Player player;
	private World world;
	private ArrayList<NonPlayableFighter> weakFoes;
	private ArrayList<NonPlayableFighter> strongFoes;
	private ArrayList<Attack> attacks;
    private ArrayList<Dragon> dragons;
    
  
	public Game() throws IOException   //incomplete
	{
		strongFoes=new ArrayList<NonPlayableFighter>();
		weakFoes=new ArrayList<NonPlayableFighter>();
		attacks=new ArrayList<Attack>();
		dragons=new ArrayList<Dragon>();
		world=new World();
		
			
				loadAttacks("Database-Attacks.csv");
			
				loadFoes("Database-Foes.csv");
			
				loadDragons("Database-Dragons.csv");
			
		
		//player,world, und alle dragon lists
		
		
		world.generateMap(weakFoes, strongFoes);
	}
	

	private ArrayList<String[]>loadCSV(String filePath) throws IOException {
		String currentLine = "";
		FileReader fileReader = new FileReader(filePath);
		BufferedReader br = new BufferedReader(fileReader);
		ArrayList <String> Info = new ArrayList <String>();
		String[] tempinfo;
		ArrayList<String[]> out = new ArrayList <String[]>();
	
	
		
		
		while ((currentLine = br.readLine()) != null) 
		{
			tempinfo=currentLine.split(",");
			/*for (int i=0;i<tempinfo.length;i++)
			{
				Info.add(tempinfo[i]);
			}*/
			out.add(tempinfo);
		}
			
		return out;
		
		
	}//end of load csv
	
	private void loadAttacks(String filePath) throws IOException
	{
		ArrayList<String[]> out=loadCSV(filePath);
		
			String type;
			String name;
			int damage;
			String []first=new String[99];
			
			for(int s=0;s<out.size();s++)
			{
			
				first=out.get(s);
				type=first[0];
				name=first[1];damage=Integer.parseInt(first[2]);
				
				
					
				switch(type)
				{
				case "SA": attacks.add(new SuperAttack(name, damage));break;
				case"UA": attacks.add(new UltimateAttack(name, damage));break;
				case"MC": attacks.add(new MaximumCharge());break;
				case"SS": attacks.add(new SuperSaiyan());break; //fehler?? jedes mal neues superatt??
				
				}//attacks is arraylist of all types of attacks
				
				
				
				
			}
		
			
		
	}
	private void loadFoes(String filePath)throws IOException{
	ArrayList<String[]> out=loadCSV(filePath);
	
//	if(filePath.equals("Database-Foes.csv"))
	{
		
		
		for(int s=0;s<out.size();s=s+3)//out.size()
		{	
			ArrayList<SuperAttack>superattacks=new ArrayList<SuperAttack>();
			ArrayList<UltimateAttack>ultimateattacks=new ArrayList<UltimateAttack>();
			String []one= out.get(s);
			
			String[]two = out.get(s+1);
			
			String[]three=out.get(s+2);
		
			int damage=0;
			//loadAttacks("Database-Attacks.csv");
			//super
			for(int m=0;m<two.length;m++)
			{	
				if(two[m]!=null&& !two[m].equals("\n")&& ! two[m].equals(""))
				{
			for(int n=0;n<attacks.size();n++)
			{
				
				if(attacks.get(n).getName().equalsIgnoreCase(two[m])){
				damage=attacks.get(n).getDamage();
				break;
				}	
			}
			if(two[m].equals("Maximum Charge")){
				superattacks.add(new MaximumCharge());
			} else {
				
			superattacks.add(new SuperAttack(two[m], damage));
				}
			}
		}	
			
			//ultimate
			for(int m=0;m<three.length;m++)
			{	
				if(three[m]!=null)
				{
					
			for(int n=0;n<91;n++)
			{
				{
				if(attacks.get(n).getName().equals(three[m]))
				damage=attacks.get(n).getDamage();
				}
					
					
			}
			
			ultimateattacks.add(new UltimateAttack(three[m], damage));
				}
			}
			int max=Integer.parseInt(one[2]);
			if(one[one.length-1].equals("TRUE"))
			{
				strongFoes.add(new NonPlayableFighter (one[0], Integer.parseInt(one[1]),max,Integer.parseInt(one[3]),Integer.parseInt(one[4]),Integer.parseInt(one[5]),Integer.parseInt(one[6]),true, superattacks, ultimateattacks));
				
			}
			
			else
			{
				weakFoes.add(new NonPlayableFighter (one[0], Integer.parseInt(one[1]),Integer.parseInt(one[2]),Integer.parseInt(one[3]),Integer.parseInt(one[4]),Integer.parseInt(one[5]),Integer.parseInt(one[6]),false, superattacks, new ArrayList<UltimateAttack>()));
			}
		}
	}
}

			
		
		
		


		
		
	
	private void loadDragons(String filePath) throws IOException
	{
	    int c = 0 ;
		ArrayList<String[]> out=loadCSV(filePath);
		String[]first=new String[out.size()];	
			for(int s=0;s<(out.size());s=s+3)
			{	
				String[]one=out.get(s);
				String[]two=out.get(s+1);
				String[]three=out.get(s+2);
				ArrayList<SuperAttack>superattacks = new ArrayList<SuperAttack>();
				ArrayList<UltimateAttack>ultimateattacks = new ArrayList<UltimateAttack>();
				String name = one[0];
				int senzu = Integer.parseInt(one[1]);
				int ability =Integer.parseInt(one[2]);
				int damage=0;
				for(int m=0;m<two.length;m++)
				{	
					if(two[m]!=null&& !two[m].equals("\n")&& ! two[m].equals(""))
					{
				for(int n=0;n<attacks.size();n++)
				{
					
					if(attacks.get(n).getName().equalsIgnoreCase(two[m])){
					damage=attacks.get(n).getDamage();
					break;
					}	
				}
				if(two[m].equals("Maximum Charge")){
					superattacks.add(new MaximumCharge());
				} else {
					
				superattacks.add(new SuperAttack(two[m], damage));
					}
				}
			}	
				
				//ultimate
				for(int m=0;m<three.length;m++)
				{	
					if(three[m]!=null)
					{
						
				for(int n=0;n<attacks.size();n++)
				{
					{
					if(attacks.get(n).getName().equals(three[m]))
					damage=attacks.get(n).getDamage();
					}
						
						
				}
				
				ultimateattacks.add(new UltimateAttack(three[m], damage));
					}
				
				}
				dragons.add(new Dragon(name, superattacks, ultimateattacks, senzu, ability))	;
				
				
			
			
		
		}
	}

	public Player getPlayer() {
		return player;
	}

	public World getWorld() {
		return world;
	}

	public ArrayList<NonPlayableFighter> getWeakFoes() {
		return weakFoes;
	}

	public ArrayList<NonPlayableFighter> getStrongFoes() {
		return strongFoes;
	}

	public ArrayList<Attack> getAttacks() {
		return attacks;
	}

	public ArrayList<Dragon> getDragons() {
		return dragons;
	}
	
public static void main(String[] args) throws IOException {
	Game g = new Game();
}	

}
