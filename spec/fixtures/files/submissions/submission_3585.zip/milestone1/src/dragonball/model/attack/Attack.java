package dragonball.model.attack;

abstract public class Attack {
	private String type;
	private String name ;
	private int  damage ;
	 
	 
public Attack(String name , int damage){
	this.name = name ;
	this.damage = damage ;
 }
///added method
public Attack(String type, String name,int damage)
{
	this(name,damage);
	this.type=type;
	
}

public String getType() {
	return type;
}
public String getName() {
	return name;
}
public int getDamage() {
	return damage;
}


}


