package dragonball.model.character.fighter;

import java.util.ArrayList;

import dragonball.model.attack.SuperAttack;
import dragonball.model.attack.UltimateAttack;
import dragonball.model.game.Game;

public class Saiyan extends PlayableFighter {
	
	private boolean transformed;
	ArrayList<SuperAttack>superAttacks;
	ArrayList<UltimateAttack>ultimateAttacks;
	Game a;
	/*public void generateautomatic() 
	{
		//Game a=new Game();///ist das erlaubt??
		ArrayList<NonPlayableFighter>strongFoes =a.getStrongFoes();
		ArrayList<NonPlayableFighter>weakFoes=a.getWeakFoes();
	for(int j=0;j<strongFoes.size();j++)
	{
		if(strongFoes.get(j).getName().equals("Saiyan"))
		{
			superAttacks=strongFoes.get(j).getSuperAttacks();
			ultimateAttacks=strongFoes.get(j).getUltimateAttacks();
		}
	}
		
	for(int i=0;i<weakFoes.size();i++)	
	{
		if(weakFoes.get(i).getName().equals("Saiyan"))
		{
			superAttacks=weakFoes.get(i).getSuperAttacks();
			ultimateAttacks=weakFoes.get(i).getUltimateAttacks();
		}
	}
	}*/
	public Saiyan(String name) {
				super(name,1000, 150,100, 5, 3,null,null);
				//generateautomatic();
				
		
		
		// TODO Auto-generated constructor stub
	}
	public Saiyan(String name,int level,int XP, int targetXP, int maxHP, int blD, int phD, int abil, int maxKi,int maxsta,
			 ArrayList<SuperAttack> superAttacks, ArrayList<UltimateAttack> ultimateAttacks)
	{
		super(name, level, XP, targetXP, maxHP, blD, phD, abil, maxKi, maxsta, superAttacks, ultimateAttacks);
	}
	public Saiyan(String name, int maxHealthPoints, int blastDamage,
			int physicalDamage, int maxKi, int maxStamina,ArrayList<SuperAttack> superAttacks,
			ArrayList<UltimateAttack> ultimateAttacks) {
		super(name,1000, 150,100, 5, 3, superAttacks,ultimateAttacks);//what about transformed
		
		
	}
	public boolean isTransformed() {
		return transformed;
	}
	public void setTransformed(boolean transformed) {
		this.transformed = transformed;
	}

}
