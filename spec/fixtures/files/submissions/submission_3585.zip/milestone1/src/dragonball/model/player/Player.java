package dragonball.model.player;

import java.util.ArrayList;

import dragonball.model.attack.SuperAttack;
import dragonball.model.attack.UltimateAttack;
import dragonball.model.character.fighter.PlayableFighter;

public class Player {
	private String name;
	private ArrayList<PlayableFighter> fighters;
	private ArrayList<SuperAttack>superAttacks;
	private int senzuBeans;
	private int dragonBalls;
	private PlayableFighter activeFighter;
	private int exploredMaps;
	private ArrayList<UltimateAttack> ultimateAttacks;
	
	public Player(String name)
	{
		this.name=name;
		this.fighters=new ArrayList<PlayableFighter>();
		this.superAttacks=new ArrayList<SuperAttack>();
		this.ultimateAttacks=new ArrayList<UltimateAttack>();
	}
	public Player(String name, ArrayList<PlayableFighter> fighters, ArrayList<SuperAttack>
	superAttacks,ArrayList<UltimateAttack>ultimateAttacks,int senzuBeans, int dragonBalls,
	PlayableFighter activeFighter, int exploredMaps)
	{
		this(name);
		this.fighters=fighters;
		this.superAttacks=superAttacks;
		this.ultimateAttacks=ultimateAttacks;
		this.senzuBeans=senzuBeans;
		this.activeFighter= activeFighter;                      
		this.exploredMaps=exploredMaps;
		this.fighters=fighters;
		this.dragonBalls=dragonBalls;
	}
	
	
	public String getName() {
		return name;
	}
	public ArrayList<PlayableFighter> getFighters() {
		return fighters;
	}
	public int getSenzuBeans() {
		return senzuBeans;
	}
	public int getDragonBalls() {
		return dragonBalls;
	}
	public PlayableFighter getActiveFighter() {
		return activeFighter;
	}
	public int getExploredMaps() {
		return exploredMaps;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setFighters(ArrayList<PlayableFighter> fighters) {
		this.fighters = fighters;
	}
	public void setSenzuBeans(int senzuBeans) {
		this.senzuBeans = senzuBeans;
	}
	public void setDragonBalls(int dragonBalls) {
		this.dragonBalls = dragonBalls;
	}
	public void setActiveFighter(PlayableFighter activeFighter) {
		this.activeFighter = activeFighter;
	}
	public void setExploredMaps(int exploredMaps) {
		this.exploredMaps = exploredMaps;
	}
	public ArrayList<SuperAttack> getSuperAttacks() {
		return superAttacks;
	}
	public ArrayList<UltimateAttack> getUltimateAttacks() {
		return ultimateAttacks;
	}
	public void setSuperAttacks(ArrayList<SuperAttack> superAttacks) {
		this.superAttacks = superAttacks;
	}
	public void setUltimateAttacks(ArrayList<UltimateAttack> ultimateAttacks) {
		this.ultimateAttacks = ultimateAttacks;
	}


}
