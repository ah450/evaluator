package dragonball.model.world;

import java.util.ArrayList;
import java.util.Random;

import dragonball.model.cell.Cell;
import dragonball.model.cell.Collectible;
import dragonball.model.cell.CollectibleCell;
import dragonball.model.cell.EmptyCell;
import dragonball.model.cell.FoeCell;
import dragonball.model.character.fighter.NonPlayableFighter;
import dragonball.model.game.Game;

public class World {
	private Cell[][] map;
	private int playerColumn;
	private int playerRow;
	
	
	public World()
	{
		map=new Cell[10][10];
		playerColumn=9;
		playerRow=9;
	}
	public void generateMap(ArrayList<NonPlayableFighter> weakFoes, ArrayList<NonPlayableFighter>
	strongFoes)
	{
		Random generator=new Random();
		if(strongFoes !=null&& weakFoes !=null)
		{
		int i=(int)(((strongFoes.size())*Math.random()));//check if constructor is possible(strong foe)
		
		if(strongFoes.get(i)!=null)
		{
		map[0][0]=new FoeCell(strongFoes.get(i));//wie ist list gefuellt?
		}
		System.out.println(strongFoes.size());
		
		for(int c=0;c<15;c++)
		{//only if cell is emptyyyyyyyy hal da fati?(weak foes)
			//Game a=new Game();
			//a.loadFoes("Database-Foes.csv");
			
			int v=(generator.nextInt(10));
			int b=(generator.nextInt(10));
			int d=(int)(8*Math.random());
			
			
			if((map[v][b]) ==null && (v!=9 && b!=9)&&(v!=0&&b!=0))
			{
			map[v][b]=new FoeCell(weakFoes.get(d));
			
			}
			else
			{
				c--;
			}
						
			
		}
		
		
		int j =3+ (int)(Math.random()*3);// sa7?? (senzu)
		for(int c=0;c<j;c++)
		{//only if cell is emptyyyyyyyyyyyyyyyyyyyyyyyyyyyyyy hal da fati?
			int a=(int)(10*Math.random());
			int b=generator.nextInt(10);
			if(map[a][b]==null && (a!=9 || b!=9)&&(a!=0||b!=0))
			{
			map[a][b]=new CollectibleCell(Collectible.SENZU_BEAN);
			}
			else
			{
				c--;
			}
		}
		
		int a=generator.nextInt(10);
		int b=generator.nextInt(10);
		while(map[a][b] ==null && (a!=9 || b!=9) && (a!=0||b!=0))		
		{
			map[a][b]=new CollectibleCell(Collectible.DRAGON_BALL);
			break;
		}
		}
		//end of generateMap
		
		for(int x=0;x<map.length;x++)
		{
			for(int y=0;y<map[x].length;y++)
			{
			if(map[x][y]==null)
				map[x][y]= new EmptyCell();
			}
				
		}
		
	}
	
	
	public String toString()
	{
		String view="";
		for(int y=0;y<10;y++)
		{
			for(int x=0;x<10;x++)
			{
				view= view+ map[y][x].toString();
			}
			view+="\n";
		}
		return view;
	}
	public Cell[][] getMap() {
		return map;
	}
	public int getPlayerColumn() {
		return playerColumn;
	}
	public int getPlayerRow() {
		return playerRow;
	}

}
