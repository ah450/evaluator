package dragonball.model.character.fighter;

import java.util.ArrayList;

import dragonball.model.attack.SuperAttack;
import dragonball.model.attack.UltimateAttack;

public class Majin extends PlayableFighter{
	public Majin(String name) {
		super(name,1500, 50, 50, 3, 6,null,null);
		//generateautomatic();
		


// TODO Auto-generated constructor stub
}
	public Majin(String name, int maxHealthPoints, int blastDamage,
			int physicalDamage, int maxKi, int maxStamina,ArrayList<SuperAttack> superAttacks,
			ArrayList<UltimateAttack> ultimateAttacks)
	{
		super(name,1500, 50, 50, 3, 6, superAttacks,ultimateAttacks);
		// TODO Auto-generated constructor stub
	}
	 public Majin(String name,int level,int XP, int targetXP, int maxHP, int blD, int phD, int abil, int maxKi,int maxsta,
			 ArrayList<SuperAttack> superAttacks, ArrayList<UltimateAttack> ultimateAttacks)
				{
		 super(name, level, XP, targetXP, maxHP, blD, phD, abil, maxKi, maxsta, superAttacks, ultimateAttacks);
		 
				}
}
