package dragonball.model.character.fighter;

import java.util.ArrayList;

import dragonball.model.attack.SuperAttack;
import dragonball.model.attack.UltimateAttack;
import dragonball.model.game.Game;

public class Namekian extends PlayableFighter{
	ArrayList<SuperAttack>superAttacks;
	ArrayList<UltimateAttack>ultimateAttacks;
	Game a;
	/*public void generateautomatic() 
	{
		//Game a=new Game();///ist das erlaubt??
		ArrayList<NonPlayableFighter>strongFoes =a.getStrongFoes();
		ArrayList<NonPlayableFighter>weakFoes=a.getWeakFoes();
	for(int j=0;j<strongFoes.size();j++)
	{
		if(strongFoes.get(j).getName().equals("Namekian"))
		{
			superAttacks=strongFoes.get(j).getSuperAttacks();
			ultimateAttacks=strongFoes.get(j).getUltimateAttacks();
		}
	}
		
	for(int i=0;i<weakFoes.size();i++)	
	{
		if(weakFoes.get(i).getName().equals("Namekian"))
		{
			superAttacks=weakFoes.get(i).getSuperAttacks();
			ultimateAttacks=weakFoes.get(i).getUltimateAttacks();
		}
	}
	}*/
	public Namekian(String name) {
				super(name,1350, 0, 50, 3, 5,null,null);
				//generateautomatic();
				
		
		
		// TODO Auto-generated constructor stub
	}
	public Namekian(String name, int maxHealthPoints, int blastDamage,
			int physicalDamage, int maxKi, int maxStamina,ArrayList<SuperAttack> superAttacks,
			ArrayList<UltimateAttack> ultimateAttacks) {
		super(name,1350, 0, 50, 3, 5, superAttacks, ultimateAttacks);
		// TODO Auto-generated constructor stub
	}
	
	public Namekian(String name, int level, int xp, int targetXp, int maxHealthPoints,
			int blastDamage, int physicalDamage, int abilityPoints, int maxKi, int maxStamina,ArrayList<SuperAttack> superAttacks,
			ArrayList<UltimateAttack> ultimateAttacks)
			{
			super(name, level, xp, targetXp,maxHealthPoints,blastDamage,physicalDamage,abilityPoints,maxKi,maxStamina,superAttacks,ultimateAttacks);
			}
	

}
