package dragonball.model.battle;

public class Battle {
	private BattleOpponent me;
	private BattleOpponent foe;
	private BattleOpponent currentOpponent;
	
	public Battle(BattleOpponent me, BattleOpponent foe)
	{
	  this.me=me;
	  this.foe=foe;
	  
	}

	public BattleOpponent getMe() {
		return me;
	}

	public BattleOpponent getFoe() {
		return foe;
	}

	public BattleOpponent getCurrentOpponent() {
		return currentOpponent;
	}

}
