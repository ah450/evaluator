package dragonball.model.character.fighter;

import java.util.ArrayList;

import dragonball.model.attack.Attack;
import dragonball.model.attack.SuperAttack;
import dragonball.model.attack.UltimateAttack;
import dragonball.model.game.Game;

public class Frieza extends PlayableFighter{
	ArrayList<SuperAttack> superAttacks;
	ArrayList<UltimateAttack>ultimateAttacks;
	Game a;//ist das moeglich
	
	
	public void generateautomatic() 
	{
		//Game a=new Game();///ist das erlaubt??
		ArrayList<NonPlayableFighter>strongFoes =a.getStrongFoes();
		ArrayList<NonPlayableFighter>weakFoes=a.getWeakFoes();
	for(int j=0;j<strongFoes.size();j++)
	{
		if(strongFoes.get(j).getName().equals("Frieza"))
		{
			superAttacks=strongFoes.get(j).getSuperAttacks();
			ultimateAttacks=strongFoes.get(j).getUltimateAttacks();
		}
	}
		
	for(int i=0;i<weakFoes.size();i++)	
	{
		if(weakFoes.get(i).getName().equals("Frieza"))
		{
			superAttacks=weakFoes.get(i).getSuperAttacks();
			ultimateAttacks=weakFoes.get(i).getUltimateAttacks();
		}
	}
	}
	public Frieza(String name) {
		
				super(name,1100, 75, 75, 4, 4,null,null);
				//generateautomatic();
				
		
		
		// TODO Auto-generated constructor stub
	}
	public Frieza(String name,int level,int XP, int targetXP, int maxHP, int blD, int phD, int abil, int maxKi,int maxsta,
			 ArrayList<SuperAttack> superAttacks, ArrayList<UltimateAttack> ultimateAttacks)
				{
		 super(name, level, XP, targetXP, maxHP, blD, phD, abil, maxKi, maxsta, superAttacks, ultimateAttacks);
		 
		 
				}
	public Frieza(String name, int maxHealthPoints, int blastDamage,
			int physicalDamage, int maxKi, int maxStamina,ArrayList<SuperAttack> superAttacks,
			ArrayList<UltimateAttack> ultimateAttacks) {
		super(name,1350, 0, 50, 3, 5, superAttacks, ultimateAttacks);
		// TODO Auto-generated constructor stub
	}


}
