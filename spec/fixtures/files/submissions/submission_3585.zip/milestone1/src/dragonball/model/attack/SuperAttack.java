package dragonball.model.attack;

import java.io.IOException;
import java.util.ArrayList;

import dragonball.model.game.Game;

public class SuperAttack extends Attack {
	
	private ArrayList<SuperAttack> types = new ArrayList<SuperAttack>();
	
	
	public SuperAttack(String name, int damage) {
		
		super(name, damage);

		
		
		
		// TODO Auto-generated constructor stub
	}


	public ArrayList<SuperAttack> getSuperattacks() throws IOException  {
		Game a=new Game();///ist das erlaubt??
		ArrayList<Attack> attacks=a.getAttacks();
		for(int i=0;i<attacks.size();i++)
		{
			if(attacks.get(i) instanceof SuperAttack)
			{
				types.add((SuperAttack)attacks.get(i));
			}
		}
		return types;
	}
	
	

}
