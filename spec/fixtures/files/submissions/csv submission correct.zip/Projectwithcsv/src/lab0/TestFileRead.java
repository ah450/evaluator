package lab0;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Scanner;

public class TestFileRead {

	public static int countLines() throws FileNotFoundException {
		int line = 0;
			Scanner sc  = new Scanner(new FileReader((new File("").getAbsolutePath())+"/src/file.csv"));
			while(sc.hasNext()) {
				sc.nextLine();
				line++;
			}
			sc.close();
		
		return line;
	}
}
