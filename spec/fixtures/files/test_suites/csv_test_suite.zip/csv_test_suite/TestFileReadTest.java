
import static org.junit.Assert.*;

import java.io.FileNotFoundException;

import lab0.TestFileRead;

import org.junit.Test;


public class TestFileReadTest {
	/**
	* @grade 40
	* 
	*/
	@Test
	public void countLines() throws FileNotFoundException {
		assertEquals("should count 2 lines in file.csv",2, TestFileRead.countLines());
	}
	
}
